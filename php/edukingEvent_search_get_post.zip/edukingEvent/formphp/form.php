<p>Enter data and click send</p>

<form action="process_form.php" method="get">
    <p>Name: <br> <input type="text" name="name" /></p>
    <p>Age: <br> <input type="text" name="age" /></p>
    <p><input type="submit" name="submit" value="Send" /></p>
</form>